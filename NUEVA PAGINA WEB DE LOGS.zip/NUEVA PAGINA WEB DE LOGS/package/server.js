import express from "express";
import axios from "axios";

const app = express();
const PORT = 4000;

// 🔧 Configura tu destino y logtab
const logtabId = 3;
const userId = 1;
const TOKEN = `push_${logtabId}_${userId}`;
const TARGET = `http://localhost:3000/api/logs/push/${TOKEN}`;

// 🧾 Genera una línea de log simple (tipo basic.js)
function generateLogLine() {
  const timestamp = new Date().toISOString();
  const level = ["INFO", "WARN", "ERROR"][Math.floor(Math.random() * 3)];
  const module = ["auth", "db", "api", "worker"][Math.floor(Math.random() * 4)];
  const message = ["User connected", "Request failed", "Data updated", "Timeout"][Math.floor(Math.random() * 4)];
  return `${timestamp} ${level} ${module} ${message}`;
}

// 🚀 Envía logs cada 5 segundos
async function sendLog() {
  const lines = Array.from({ length: 5 }, generateLogLine).join("\n");
  const payload = {
    logtabId,
    data: lines,
    timestamp: new Date().toISOString()
  };

  try {
    const res = await axios.post(TARGET, payload, {
      headers: { "Content-Type": "application/json" },
      timeout: 5000
    });
    console.log(`✅ Logs enviados (${res.status}) -> ${res.data.id || "OK"}`);
  } catch (err) {
    console.error("❌ Error enviando logs:", err.response?.data || err.message);
  }
}

// ⏱ Intervalo
setInterval(sendLog, 5000);

// 🌐 Pequeño servidor para control visual
app.get("/", (req, res) => {
  res.send(`
    <h3>Servidor LogSender activo 🚀</h3>
    <p>Enviando logs cada 5 segundos a:</p>
    <code>${TARGET}</code>
    <pre>${JSON.stringify({ logtabId, sample: generateLogLine() }, null, 2)}</pre>
  `);
});

app.listen(PORT, () => {
  console.log(`🟢 LogSender activo en http://localhost:${PORT}`);
  console.log(`📡 Enviando a ${TARGET}`);
});
