// Variables para logtabs
let isEditing = false;
let currentLogtabs = [];

// Elementos DOM para logtabs
const saveLogtabBtn = document.getElementById('saveLogtabBtn');
const cancelEditBtn = document.getElementById('cancelEditBtn');
const logtabsListEl = document.getElementById('logtabsList');
const selectedLogtabEl = document.getElementById('selectedLogtab');
const logtabModeEl = document.getElementById('logtabMode');
const logtabTypeEl = document.getElementById('logtabType');
const logtabSourceUrlEl = document.getElementById('logtabSourceUrl');
const logtabCategoryEl = document.getElementById('logtabCategory');
const logtabPluginEl = document.getElementById('logtabPlugin');
const pullFieldsEl = document.querySelectorAll('.pull-fields');
const socketFieldEl = document.querySelector('.socket-field');
const pushEndpointUrlEl = document.getElementById('pushEndpointUrl');

// Funciones de Logtabs
function saveLogtab() {
    if (isEditing) {
        updateLogtab();
    } else {
        createLogtab();
    }
}

// Manejar cambio de modo
function handleModeChange() {
    const mode = logtabModeEl.value;
    
    if (mode === 'push') {
        // Mostrar campos PUSH, ocultar campos PULL
        pullFieldsEl.forEach((el => el.classList.toggle('hidden', true)));
        
        // Actualizar endpoint push si estamos editando
        if (isEditing) {
            updatePushEndpoint();
        }
    } else {
        pullFieldsEl.forEach((el => el.classList.toggle('hidden', false)));
        
        // Manejar tipo dentro de PULL
        handleTypeChange();
    }
}

// Manejar cambio de tipo (solo en modo PULL)
function handleTypeChange() {
    const type = logtabTypeEl.value;
    
    if (type === 'socket') {
        socketFieldEl.classList.remove('hidden');
        logtabSourceUrlEl.placeholder = "ws://servidor:puerto o wss://servidor:puerto";
    } else {
        socketFieldEl.classList.add('hidden');
        logtabSourceUrlEl.placeholder = "http://ejemplo.com/logs o https://ejemplo.com/logs";
    }
}

// Actualizar endpoint push para mostrar
function updatePushEndpoint() {
    const logtabId = document.getElementById('logtabId').value;
    if (logtabId && currentUser) {
        const pushUrl = `${window.location.origin}/api/logs/push/push_${logtabId}_${currentUser.id}`;
        pushEndpointUrlEl.textContent = `POST ${pushUrl}`;
    }
}

async function createLogtab() {
    const name = document.getElementById('logtabName').value;
    const mode = document.getElementById('logtabMode').value;
    const type = document.getElementById('logtabType').value;
    const plugin = document.getElementById('logtabPlugin').value;
    const sourceUrl = document.getElementById('logtabSourceUrl').value;
    
    
    // Validaciones básicas
    if (!name || !plugin) {
        showNotification('Por favor, completa nombre y plugin', 'error');
        return;
    }
    
    // Para modo PULL, tipo y URL son obligatorios
    if (mode === 'pull') {
        if (!type || !sourceUrl) {
            showNotification('Para modo PULL, tipo y URL son obligatorios', 'error');
            return;
        }
    }
    
    try {
    const category = document.getElementById('logtabCategory')?.value || '';

    const response = await fetch('/api/logtabs', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({ name, mode, type, plugin, sourceUrl, category })
    });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Logtab creado exitosamente', 'success');
            resetLogtabForm();
            loadLogtabs();
        } else {
            showNotification(data.error || 'Error al crear logtab', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error de conexión', 'error');
    }
}

async function updateLogtab() {
    const id = document.getElementById('logtabId').value;
    const name = document.getElementById('logtabName').value;
    const mode = document.getElementById('logtabMode').value;
    const type = document.getElementById('logtabType').value;
    const plugin = document.getElementById('logtabPlugin').value;
    const sourceUrl = document.getElementById('logtabSourceUrl').value;
    
    // Validaciones básicas
    if (!name || !plugin) {
        showNotification('Por favor, completa nombre y plugin', 'error');
        return;
    }
    
    // Para modo PULL, tipo y URL son obligatorios
    if (mode === 'pull') {
        if (!type || !sourceUrl) {
            showNotification('Para modo PULL, tipo y URL son obligatorios', 'error');
            return;
        }
    }
    
    try {
    const category = document.getElementById('logtabCategory')?.value || '';

    const response = await fetch(`/api/logtabs/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({ name, mode, type, plugin, sourceUrl, category })
    });

        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Logtab actualizado exitosamente', 'success');
            resetLogtabForm();
            loadLogtabs();
        } else {
            showNotification(data.error || 'Error al actualizar logtab', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error de conexión', 'error');
    }
}

function editLogtab(id) {
    const logtab = currentLogtabs.find(lt => lt.id === id);
    if (!logtab) return;
    
    document.getElementById('logtabId').value = logtab.id;
    document.getElementById('logtabName').value = logtab.name;
    document.getElementById('logtabMode').value = logtab.mode || 'pull';
    document.getElementById('logtabType').value = logtab.type || 'endpoint';
    document.getElementById('logtabPlugin').value = logtab.plugin;
    document.getElementById('logtabSourceUrl').value = logtab.sourceUrl || '';
    
    // Actualizar UI según el modo y tipo
    handleModeChange();
    
    saveLogtabBtn.textContent = 'Actualizar Logtab';
    cancelEditBtn.classList.remove('hidden');
    isEditing = true;
    
    // Scroll al formulario
    document.getElementById('logtabForm').scrollIntoView({ behavior: 'smooth' });
}

function cancelEdit() {
    resetLogtabForm();
}

function resetLogtabForm() {
    document.getElementById('logtabId').value = '';
    document.getElementById('logtabName').value = '';
    document.getElementById('logtabMode').value = 'pull';
    document.getElementById('logtabType').value = 'endpoint';
    document.getElementById('logtabPlugin').value = '';
    document.getElementById('logtabSourceUrl').value = '';
    
    // Resetear UI
    handleModeChange();
    
    saveLogtabBtn.textContent = 'Crear Logtab';
    cancelEditBtn.classList.add('hidden');
    isEditing = false;
}

async function loadLogtabs() {
    try {
        const response = await fetch('/api/logtabs', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentLogtabs = data.logtabs;
            displayLogtabs(data.logtabs);
            updateLogtabSelector(data.logtabs);
        } else {
            showNotification(data.error || 'Error al cargar logtabs', 'error');
        }
    } catch (error) {
        console.error('Error:', error); 
        showNotification('Error de conexión', 'error');
    }
}

function displayLogtabs(logtabs) {
    if (!logtabs || logtabs.length === 0) {
        logtabsListEl.innerHTML = '<div class="empty-state"><p>No hay logtabs creados. ¡Crea el primero!</p></div>';
        return;
    }
    
    let html = '<div class="table-container"><table><thead><tr><th>Nombre</th><th>Modo</th><th>Tipo</th><th>Plugin</th><th>URL/Endpoint</th><th>Acciones</th></tr></thead><tbody>';
    
    logtabs.forEach(logtab => {
        // Determinar badges
        const modeBadge = logtab.mode === 'push' ? 'badge-success' : 'badge-primary';
        const modeText = logtab.mode === 'push' ? 'PUSH' : 'PULL';
        
        const typeBadge = logtab.type === 'socket' ? 'badge-warning' : 'badge-info';
        const typeText = logtab.type === 'socket' ? 'WebSocket' : 'HTTP';
        
        let urlDisplay = logtab.sourceUrl || '-';
        if (logtab.mode === 'push') {
            const pushUrl = `${window.location.origin}/api/logs/push/push_${logtab.id}_${logtab.userId}`;
            urlDisplay = `<span title="Endpoint para enviar logs: POST ${pushUrl}">
                <strong>🔗 Push Endpoint</strong><br>
                <small>POST ${pushUrl}</small>
            </span>`;
        } else if (logtab.type === 'socket') {
            urlDisplay = `<span class="socket-url">${logtab.sourceUrl}</span>`;
        }
        
        html += `
            <tr>
                <td><strong>${logtab.name}</strong></td>
                <td><span class="badge ${modeBadge}">${modeText}</span></td>
                <td><span class="badge ${typeBadge}">${typeText}</span></td>
                <td>${logtab.plugin}</td>
                <td class="url-cell">${urlDisplay}</td>
                <td class="action-buttons">
                    <button class="btn-warning" onclick="editLogtab(${logtab.id})">Editar</button>
                    <button class="btn-danger" onclick="deleteLogtab(${logtab.id})">Eliminar</button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    logtabsListEl.innerHTML = html;
}

async function deleteLogtab(id) {
    if (!confirm('¿Estás seguro de que quieres eliminar este logtab?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/logtabs/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Logtab eliminado', 'success');
            loadLogtabs();
        } else {
            showNotification(data.error || 'Error al eliminar logtab', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error de conexión', 'error');
    }
}

function updateLogtabSelector(logtabs) {
    selectedLogtabEl.innerHTML = '<option value="">Selecciona un logtab</option>';
    
    if (logtabs && logtabs.length > 0) {
        logtabs.forEach(logtab => {
            const option = document.createElement('option');
            option.value = logtab.id;
            const mode = logtab.mode === 'push' ? 'PUSH' : 'PULL';
            const type = logtab.type === 'socket' ? 'WebSocket' : 'HTTP';
            option.textContent = `${logtab.name} (${mode} - ${type})`;
            selectedLogtabEl.appendChild(option);
        });
    }
    
    // Mostrar/ocultar campo de espera según el logtab seleccionado
    updateWaitMsField();
}

function updateWaitMsField() {
    const selectedId = selectedLogtabEl.value;
    const logtab = currentLogtabs.find(lt => lt.id == selectedId);
    
    if (logtab && logtab.mode === 'pull' && logtab.type === 'socket') {
        socketFieldEl.classList.remove('hidden');
    } else {
        socketFieldEl.classList.add('hidden');
    }


}
// === Barra de clasificación de logs ===
document.addEventListener('DOMContentLoaded', function() {
    const sourceUrlField = document.getElementById('logtabSourceUrl');

    if (sourceUrlField) {
        const categoryContainer = document.createElement('div');
        categoryContainer.classList.add('category-bar');
        categoryContainer.innerHTML = `
            <label for="logtabCategory" class="category-label">Clasificación de Logs:</label>
            <select id="logtabCategory" class="category-select">
                <option value="">Selecciona un tipo</option>
                <option value="error">Error</option>
                <option value="warning">Advertencia</option>
                <option value="info">Información</option>
                <option value="debug">Depuración</option>
            </select>
        `;

        // Insertar justo debajo del campo URL
        sourceUrlField.parentNode.insertBefore(categoryContainer, sourceUrlField.nextSibling);
    }
});


// Asignar event listeners para logtabs
document.addEventListener('DOMContentLoaded', function() {
    saveLogtabBtn.addEventListener('click', saveLogtab);
    cancelEditBtn.addEventListener('click', cancelEdit);
    logtabModeEl.addEventListener('change', handleModeChange);
    logtabTypeEl.addEventListener('change', handleTypeChange);
    selectedLogtabEl.addEventListener('change', updateWaitMsField);
    
    // Inicializar estado
    handleModeChange();
});