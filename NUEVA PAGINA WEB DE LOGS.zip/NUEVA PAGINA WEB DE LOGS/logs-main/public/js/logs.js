// logs.js
const logsOutputEl = document.getElementById('logsOutput');
const getLogsBtn = document.getElementById('getLogsBtn');

async function getLogs() {
    const logtabId = selectedLogtabEl.value;
    const waitMs = document.getElementById('waitMs').value;
    
    if (!logtabId) {
        showNotification('Por favor, selecciona un logtab', 'error');
        return;
    }

    logsOutputEl.innerHTML = '<div class="loading">Obteniendo logs...</div>';
    
    try {
        let url = `/api/logs/${logtabId}`;
        if (waitMs) url += `?waitMs=${waitMs}`;
        
        const response = await fetch(url, {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        const data = await response.json();
        
        if (response.ok) {
            displayLogs(data);
            showNotification('Logs obtenidos correctamente', 'success');
        } else {
            showNotification(data.error || 'Error al obtener logs', 'error');
            logsOutputEl.textContent = 'Error al obtener logs';
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error de conexión', 'error');
        logsOutputEl.textContent = 'Error de conexión al servidor';
    }
}

function displayLogs(logData) {
    let output = '';

    output += `<div class="logs-header">
        <h3>LOGS RECIBIDOS</h3>
        <div class="logs-info">
            <p><strong>Plugin:</strong> ${logData.plugin || 'N/A'}</p>
            <p><strong>Modo:</strong> ${logData.mode || 'pull'}</p>`;

    if (logData.mode === 'push') {
        output += `<p><strong>Logs almacenados:</strong> ${logData.storedCount || 0}</p>`;
        if (logData.latestTimestamp) {
            output += `<p><strong>Último log:</strong> ${new Date(logData.latestTimestamp).toLocaleString()}</p>`;
        }
    } else if (logData.collectedCount !== undefined) {
        output += `<p><strong>Mensajes recolectados:</strong> ${logData.collectedCount}</p>`;
    }

    if (logData.metadata) {
        output += `<p><strong>Filas procesadas:</strong> ${logData.metadata.rowCount || 0}</p>`;
        output += `<p><strong>Columnas:</strong> ${logData.metadata.columnCount || 0}</p>`;
    }

    output += `<p><strong>Timestamp:</strong> ${new Date().toLocaleString()}</p>
        </div>
    </div>`;

    // 🔽 Barra de filtros
    output += `
        <div class="logs-filter-bar">
            <label for="logFilterSelect">Tipo:</label>
            <select id="logFilterSelect" class="log-filter-select">
                <option value="all">Todos</option>
                <option value="ERROR">Errores</option>
                <option value="WARN">Advertencias</option>
                <option value="INFO">Información</option>
            </select>

            <label for="logDateSearch">Fecha:</label>
            <input type="date" id="logDateSearch" class="log-date-input" />

            <label for="logC3Select">C3:</label>
            <select id="logC3Select" class="log-filter-select">
                <option value="all">Todos</option>
            </select>

            <label for="logRestSelect">Rest:</label>
            <select id="logRestSelect" class="log-filter-select">
                <option value="all">Todos</option>
            </select>
        </div>
    `;

    // Tabla
    if (logData.table && logData.table.columns && logData.table.rows) {
        output += `<div class="structured-table-container">
            <h4>Datos Estructurados</h4>
            <div class="table-container">
                <table class="logs-table">
                    <thead>
                        <tr>`;
        logData.table.columns.forEach(header => output += `<th>${header}</th>`);
        output += `</tr>
                    </thead>
                    <tbody id="logsTableBody">`;

        logData.table.rows.forEach(row => {
            output += '<tr>';
            row.forEach(cell => {
                const cellContent = cell ? cell.toString() : '';
                output += `<td title="${cellContent}">${cellContent}</td>`;
            });
            output += '</tr>';
        });

        output += `</tbody>
                </table>
            </div>
        </div>`;
    } else if (!logData.html) {
        output += '<p class="no-data">No hay datos disponibles</p>';
    }

    output += `<div class="logs-footer">
        <p>Fin del registro - ${new Date().toLocaleString()}</p>
    </div>`;

    logsOutputEl.innerHTML = output;

    // 🔽 Obtener referencias
    const filterSelect = document.getElementById('logFilterSelect');
    const dateInput = document.getElementById('logDateSearch');
    const c3Select = document.getElementById('logC3Select');
    const restSelect = document.getElementById('logRestSelect');
    const rows = logsOutputEl.querySelectorAll('.logs-table tbody tr');

    // Crear listas únicas para C3 y Rest
    const c3Values = new Set();
    const restValues = new Set();

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const c3 = cells[2]?.textContent || '';
        const rest = cells[3]?.textContent || '';
        if (c3) c3Values.add(c3);
        if (rest) restValues.add(rest);
    });

    // Llenar selects con los valores únicos
    c3Values.forEach(v => {
        const option = document.createElement('option');
        option.value = v;
        option.textContent = v;
        c3Select.appendChild(option);
    });

    restValues.forEach(v => {
        const option = document.createElement('option');
        option.value = v;
        option.textContent = v;
        restSelect.appendChild(option);
    });

    // 🔍 Aplicar filtros combinados
    function applyFilters() {
        const typeVal = filterSelect.value;
        const dateVal = dateInput.value;
        const c3Val = c3Select.value;
        const restVal = restSelect.value;

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const fecha = cells[0]?.textContent || '';
            const tipo = cells[1]?.textContent || '';
            const c3 = cells[2]?.textContent || '';
            const rest = cells[3]?.textContent || '';

            let visible = true;

            if (typeVal !== 'all' && tipo !== typeVal) visible = false;
            if (dateVal && !fecha.includes(dateVal)) visible = false;
            if (c3Val !== 'all' && c3 !== c3Val) visible = false;
            if (restVal !== 'all' && rest !== restVal) visible = false;

            row.style.display = visible ? '' : 'none';
        });
    }

    // Eventos
    [filterSelect, dateInput, c3Select, restSelect].forEach(el =>
        el.addEventListener('change', applyFilters)
    );

    // Auto-scroll
    logsOutputEl.scrollTop = logsOutputEl.scrollHeight;
}

document.addEventListener('DOMContentLoaded', () => {
    getLogsBtn.addEventListener('click', getLogs);
});
