// Variables globales
let currentUser = null;
let authToken = localStorage.getItem('authToken');
let socket = null;

// Elementos DOM
const authModal = document.getElementById('authModal');
const authModalButton = document.getElementById('authModalButton');
const closeAuthModal = document.getElementById('closeAuthModal');
const userStatusEl = document.getElementById('userStatus');
const logtabFormEl = document.getElementById('logtabForm');
const logsControlsEl = document.getElementById('logsControls');
const notificationEl = document.getElementById('notification');

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    // Verificar si hay un token guardado
    if (authToken) {
        currentUser = JSON.parse(localStorage.getItem('currentUser'));
        updateUIForLoggedInUser();
    }
    
    // Configurar event listeners
    authModalButton.addEventListener('click', openAuthModal);
    closeAuthModal.addEventListener('click', closeAuthModalFunc);
    
    // Event listeners para pestañas del modal
    document.querySelectorAll('.modal-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            switchTab(tabName);
        });
    });
    
    // Cerrar modal al hacer clic fuera
    window.addEventListener('click', function(event) {
        if (event.target === authModal) {
            closeAuthModalFunc();
        }
    });
});

// Funciones del modal de autenticación
function openAuthModal() {
    authModal.style.display = 'flex';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('regUsername').value = '';
    document.getElementById('regPassword').value = '';
    
    if (currentUser) {
        userStatusEl.textContent = `Conectado como: ${currentUser.username}`;
        userStatusEl.className = 'user-status logged-in';
        userStatusEl.classList.remove('hidden');
    } else {
        userStatusEl.textContent = 'No autenticado';
        userStatusEl.className = 'user-status logged-out';
        userStatusEl.classList.remove('hidden');
    }
}

function closeAuthModalFunc() {
    authModal.style.display = 'none';
}

function switchTab(tabName) {
    // Actualizar pestañas activas
    document.querySelectorAll('.modal-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`.modal-tab[data-tab="${tabName}"]`).classList.add('active');
    
    // Actualizar paneles activos
    document.querySelectorAll('.modal-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    document.getElementById(`${tabName}Panel`).classList.add('active');
}

// Funciones de UI
function updateUIForLoggedInUser() {
    authModalButton.textContent = `Cerrar Sesión (${currentUser.username})`;
    authModalButton.onclick = logout;
    logtabFormEl.classList.remove('hidden');
    logsControlsEl.classList.remove('hidden');
    
    // Cargar los logtabs del usuario
    loadLogtabs();
    
    // Inicializar conexión de socket
    initSocketConnection();
}

function updateUIForLoggedOutUser() {
    authModalButton.textContent = 'Iniciar Sesión';
    authModalButton.onclick = openAuthModal;
    logtabFormEl.classList.add('hidden');
    logsControlsEl.classList.add('hidden');
    document.getElementById('logtabsList').innerHTML = '';
    document.getElementById('logsOutput').textContent = 'Los logs aparecerán aquí...';
    resetLogtabForm();
}

function initSocketConnection() {
    // Conectar al servidor de sockets
    socket = io();
    
    socket.on('connect', () => {
        console.log('Conectado al servidor de sockets');
        showNotification('Conectado al servidor en tiempo real', 'success');
    });
    
    socket.on('disconnect', () => {
        console.log('Desconectado del servidor de sockets');
        showNotification('Desconectado del servidor', 'error');
    });
    
    // Escuchar actualizaciones de logs en tiempo real
    socket.on('logUpdate', (data) => {
        if (data.logtabId === document.getElementById('selectedLogtab').value) {
            displayLogs(data);
        }
    });
}

function showNotification(message, type) {
    notificationEl.textContent = message;
    notificationEl.className = `notification ${type}`;
    notificationEl.style.opacity = '1';
    
    setTimeout(() => {
        notificationEl.style.opacity = '0';
    }, 4000);
}