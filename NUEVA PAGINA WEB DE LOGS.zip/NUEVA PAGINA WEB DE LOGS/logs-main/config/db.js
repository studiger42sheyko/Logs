import sqlite3 from "sqlite3";
import { open } from "sqlite";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";
dotenv.config();

const dbFile = process.env.DB_FILE || path.join(process.cwd(), "data", "logviewer.db");
const dbDir = path.dirname(dbFile);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

let db;

export async function connectDB() {
  if (!db) {
    db = await open({
      filename: dbFile,
      driver: sqlite3.Database,
    });

    await db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
      );
    `);

    await db.exec(`
      CREATE TABLE IF NOT EXISTS push_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        logtabId INTEGER NOT NULL,
        data TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (logtabId) REFERENCES logtabs (id) ON DELETE CASCADE
      );

      CREATE INDEX IF NOT EXISTS idx_push_logs_logtabId ON push_logs(logtabId);
      CREATE INDEX IF NOT EXISTS idx_push_logs_timestamp ON push_logs(timestamp);
    `);

    await db.exec(`
      CREATE TABLE IF NOT EXISTS logtabs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userId INTEGER,
        name TEXT NOT NULL,
        type TEXT CHECK(type IN ('endpoint','socket')) NOT NULL,
        plugin TEXT NOT NULL,
        sourceUrl TEXT NOT NULL,
        pushEndpoint TEXT,
        mode TEXT NOT NULL DEFAULT 'pull',
        FOREIGN KEY(userId) REFERENCES users(id)
      );
    `);
  }

  return db;
}
