import express from "express";
import axios from "axios";
import { verifyTokenMiddleware } from "../config/auth.js";
import { LogtabModel } from "../models/logtabModel.js";
import { PushLogModel } from "../models/pushLogModel.js";
import fs from "fs";
import path from "path";
import { URL } from "url";
import socketClientManager from "../clients/socketClients.js";
import dotenv from "dotenv";
import { pathToFileURL } from "url";
dotenv.config();

const router = express.Router();

const PLUGINS_DIR = path.join(process.cwd(), "plugins");

// En logs.js - modificar la función loadPlugin
export async function loadPlugin(pluginIdOrFilename) {
  const files = fs.readdirSync(PLUGINS_DIR).filter(f => f.endsWith(".js"));
  const candidate = files.find(f =>
    f.toLowerCase().startsWith(pluginIdOrFilename.toLowerCase())
  );

  if (!candidate) throw new Error("plugin_not_found");

  const full = path.join(PLUGINS_DIR, candidate);
  const fullUrl = pathToFileURL(full).href;

  try {
    const module = await import(`${fullUrl}?update=${Date.now()}`);
    const plugin = module.default || module;

    // Verificar que el plugin tenga la función getTable actualizada
    if (!plugin || typeof plugin.getTable !== "function") {
      console.error("❌ Plugin inválido:", pluginIdOrFilename);
      throw new Error("invalid_plugin");
    }

    // Probar que getTable devuelva el formato correcto
    const testResult = plugin.getTable("test\nline");
    if (!testResult || !testResult.html || !testResult.table) {
      console.error("❌ Plugin con formato incorrecto:", pluginIdOrFilename);
      throw new Error("invalid_plugin_format");
    }

    console.log(`✅ Plugin '${pluginIdOrFilename}' cargado (${candidate})`);
    return plugin;
  } catch (err) {
    console.error("❌ Error al importar plugin:", pluginIdOrFilename, err);
    throw new Error("plugin_load_failed");
  }
}

function validateExternalUrl(u) {
  if (!["http:", "https:", "ws:", "wss:"].includes(u.protocol)) throw new Error("invalid_protocol");
  const allowLocal = process.env.ALLOW_LOCALHOST_SOURCES === "true";
  if (!allowLocal) {
    if (["localhost", "127.0.0.1", "::1"].includes(u.hostname)) throw new Error("local_not_allowed");
  }
}

// GET /api/logs/:id - Obtener logs (todos los modos)
router.get("/:id", verifyTokenMiddleware, async (req, res) => {
  const id = Number(req.params.id);
  const logtab = await LogtabModel.findById(id);
  if (!logtab) return res.status(404).json({ error: "logtab_not_found" });
  if (logtab.userId !== req.user.id) return res.status(403).json({ error: "not_owner" });

  let plugin;
  try {
    plugin = await loadPlugin(logtab.plugin);
  } catch (err) {
    return res.status(400).json({ error: err.message || "plugin_error" });
  }

  try {
    if (logtab.mode === 'push') {
      // MODO PUSH: Obtener logs almacenados de nuestra base de datos
      const limit = Number(req.query.limit) || 1000;
      const storedLogs = await PushLogModel.findByLogtabId(id, limit);
      
      if (storedLogs.length === 0) {
        return res.json({ 
          plugin: plugin.id || plugin.name, 
          table: { headers: [], rows: [] },
          mode: 'push',
          message: 'No hay logs almacenados'
        });
      }

      const combinedData = storedLogs.map(log => log.data).join('\n');
      const table = plugin.getTable(combinedData);
      
      return res.json({ 
        plugin: plugin.id || plugin.name, 
        html: table.html,
        table: table.table,
        mode: 'push',
        storedCount: storedLogs.length,
        latestTimestamp: storedLogs[0].timestamp
      });

    } else {
      // MODO PULL: Nuestro servidor obtiene logs de fuente externa
      try {
        const src = new URL(logtab.sourceUrl);
        validateExternalUrl(src);
      } catch (e) {
        return res.status(400).json({ error: e.message || "invalid_source" });
      }

      if (logtab.type === "endpoint") {
        // GET a servidor externo
        const resp = await axios.get(logtab.sourceUrl, { timeout: 5000, responseType: "text" }).catch(e => {
          throw new Error("remote_request_failed");
        });
        const text = typeof resp.data === "string" ? resp.data : JSON.stringify(resp.data);
        const table = plugin.getTable(text);
        return res.json({ 
          plugin: plugin.id || plugin.name, 
          html: table.html,
          table: table.table,
          metadata: table.metadata,
          mode: 'pull'
        });
      } else if (logtab.type === "socket") {
        // Conexión WebSocket a servidor externo
        const ms = Number(req.query.waitMs || 2000);
        const collected = await socketClientManager.collectFor(logtab.sourceUrl, ms);
        const text = collected.map(c => (typeof c === "string" ? c : JSON.stringify(c))).join("\n");
        const table = plugin.getTable(text);
        return res.json({ 
          plugin: plugin.id || plugin.name, 
          html: table.html,
          table: table.table,
          metadata: table.metadata,
          collectedCount: collected.length, 
          mode: 'pull'
        });
      } else {
        return res.status(400).json({ error: "unknown_type" });
      }
    }
  } catch (err) {
    return res.status(500).json({ error: err.message || "processing_error" });
  }
});

router.post("/push/:token", async (req, res) => {
  const { token } = req.params;
  const { logtabId, data, timestamp } = req.body;
  
  if (!logtabId || !data) {
    return res.status(400).json({ error: "missing_logtabid_or_data" });
  }

  // Buscar el logtab por ID
  const logtab = await LogtabModel.findById(logtabId);
  if (!logtab) return res.status(404).json({ error: "logtab_not_found" });

  // Verificar que el logtab esté en modo push
  if (logtab.mode !== 'push') {
    return res.status(400).json({ error: "logtab_not_in_push_mode" });
  }

  // Aquí deberías implementar una validación más segura del token
  // Por ahora, un simple token en la URL
  const expectedToken = `push_${logtabId}_${logtab.userId}`;
  if (token !== expectedToken) {
    return res.status(403).json({ error: "invalid_token" });
  }

  try {
    const logEntry = await PushLogModel.create({ 
      logtabId, 
      data: typeof data === 'string' ? data : JSON.stringify(data),
      timestamp 
    });
    
    res.status(201).json({ 
      success: true, 
      id: logEntry.id,
      timestamp: logEntry.timestamp
    });
  } catch (error) {
    console.error("Error storing push log:", error);
    res.status(500).json({ error: "storage_failed" });
  }
});

// POST /api/logs/push/batch/:token - Endpoint batch para múltiples logs
router.post("/push/batch/:token", async (req, res) => {
  const { token } = req.params;
  const { logtabId, logs } = req.body;
  
  if (!logtabId || !Array.isArray(logs)) {
    return res.status(400).json({ error: "missing_logtabid_or_logs_array" });
  }

  const logtab = await LogtabModel.findById(logtabId);
  if (!logtab) return res.status(404).json({ error: "logtab_not_found" });

  if (logtab.mode !== 'push') {
    return res.status(400).json({ error: "logtab_not_in_push_mode" });
  }

  const expectedToken = `push_${logtabId}_${logtab.userId}`;
  if (token !== expectedToken) {
    return res.status(403).json({ error: "invalid_token" });
  }

  try {
    const results = [];
    for (const log of logs) {
      const logEntry = await PushLogModel.create({ 
        logtabId, 
        data: typeof log.data === 'string' ? log.data : JSON.stringify(log.data),
        timestamp: log.timestamp
      });
      results.push({ id: logEntry.id, timestamp: logEntry.timestamp });
    }
    
    res.status(201).json({ 
      success: true, 
      count: results.length,
      logs: results
    });
  } catch (error) {
    console.error("Error storing batch push logs:", error);
    res.status(500).json({ error: "batch_storage_failed" });
  }
});

export default router;