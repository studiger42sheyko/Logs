import express from "express";
import multer from "multer";
import fs from "fs";
import path from "path";

const router = express.Router();

// 📁 Directorio de plugins
const PLUGINS_DIR = path.join(process.cwd(), "plugins");
if (!fs.existsSync(PLUGINS_DIR)) fs.mkdirSync(PLUGINS_DIR, { recursive: true });

// 🧰 Configuración de Multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, PLUGINS_DIR),
  filename: (req, file, cb) => {
    const base = path.basename(file.originalname, ".js");
    cb(null, base + ".js");
  }
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (!file.originalname.endsWith(".js")) {
      return cb(new Error("invalid_extension"));
    }
    cb(null, true);
  },
  limits: { fileSize: 100 * 1024 } // 100 KB de límite
});

// 🧩 Ruta: subir plugin
// En plugin.js - actualizar la validación del contenido
router.post("/upload", upload.single("plugin"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "missing_file" });
  }

  const filename = req.file.filename;
  console.log(`🧩 Plugin subido: ${filename}`);

  try {
    // Validar dinámicamente que el plugin funciona
    const fullPath = path.join(PLUGINS_DIR, filename);
    const module = await import(pathToFileURL(fullPath).href);
    const plugin = module.default || module;

    // Validar funciones requeridas
    const requiredFunctions = ["parseLine", "parseBatch", "getTable"];
    const missingFunctions = requiredFunctions.filter(fn => typeof plugin[fn] !== "function");
    
    if (missingFunctions.length > 0) {
      return res.status(400).json({ 
        error: "missing_functions", 
        details: missingFunctions 
      });
    }

    // Validar que getTable devuelva el formato correcto
    const testResult = plugin.getTable("test\nline");
    if (!testResult || !testResult.html || !testResult.table) {
      return res.status(400).json({ 
        error: "invalid_format",
        message: "getTable debe devolver { html, table, metadata }"
      });
    }

    // Validar campos requeridos
    const requiredFields = ["id", "name", "description", "fields"];
    const missingFields = requiredFields.filter(field => !plugin[field]);
    
    if (missingFields.length > 0) {
      return res.status(400).json({ 
        error: "missing_fields", 
        details: missingFields 
      });
    }

    res.json({
      message: "plugin_uploaded",
      file: filename,
      path: `/plugins/${filename}`,
      pluginInfo: {
        id: plugin.id,
        name: plugin.name,
        description: plugin.description
      }
    });

  } catch (err) {
    console.error("❌ Error validando plugin:", err);
    return res.status(400).json({ 
      error: "plugin_validation_failed",
      message: err.message 
    });
  }
});

// 📜 Ruta: listar plugins
router.get("/list", (req, res) => {
  try {
    const files = fs.readdirSync(PLUGINS_DIR).filter(f => f.endsWith(".js"));
    const plugins = files.map(f => {
      const content = fs.readFileSync(path.join(PLUGINS_DIR, f), "utf8");
      const id = (content.match(/id:\s*["'`](.*?)["'`]/) || [])[1];
      const name = (content.match(/name:\s*["'`](.*?)["'`]/) || [])[1];
      const description = (content.match(/description:\s*["'`](.*?)["'`]/) || [])[1];
      return { file: f, id, name, description };
    });
    res.json({ plugins });
  } catch (err) {
    console.error("❌ Error al listar plugins:", err);
    res.status(500).json({ error: "list_failed" });
  }
});

export default router;
