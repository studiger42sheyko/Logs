import express from "express";
import { verifyTokenMiddleware } from "../config/auth.js";
import { LogtabModel } from "../models/logtabModel.js";
import { URL } from "url";

const router = express.Router();

// listar
router.get("/", verifyTokenMiddleware, async (req, res) => {
  const userId = req.user.id;
  const rows = await LogtabModel.listByUser(userId);
  res.json({ logtabs: rows });
});

// crear
router.post("/", verifyTokenMiddleware, (req, res) => {
  const userId = req.user.id;
  const { name, type, plugin, sourceUrl, mode = 'pull', pushEndpoint } = req.body;
  
  if (!name || !type || !plugin) return res.status(400).json({ error: "missing_fields" });
  
  // validar tipo
  if (!["endpoint", "socket"].includes(type)) return res.status(400).json({ error: "invalid_type" });
  
  // validar modo
  if (!["pull", "push"].includes(mode)) return res.status(400).json({ error: "invalid_mode" });

  // validar URL solo para modo pull
  if (mode === 'pull') {
    if (!sourceUrl) return res.status(400).json({ error: "missing_source_url_for_pull" });
    
    try {
      const u = new URL(sourceUrl);
      if (!["http:", "https:", "ws:", "wss:"].includes(u.protocol)) {
        return res.status(400).json({ error: "invalid_protocol" });
      }
    } catch (e) {
      return res.status(400).json({ error: "invalid_url" });
    }
  }

  const created = LogtabModel.create({ userId, name, type, plugin, sourceUrl, mode, pushEndpoint });
  res.status(201).json({ logtab: created });
});

// editar
router.put("/:id", verifyTokenMiddleware, async (req, res) => {
  const id = Number(req.params.id);
  const userId = req.user.id;
  const { name, type, plugin, sourceUrl, mode = 'pull', pushEndpoint } = req.body;

  // Validar que exista el registro
  const found = await LogtabModel.findById(id);
  if (!found) return res.status(404).json({ error: "not_found" });
  
  // Validar permisos de usuario
  if (found.userId !== userId) return res.status(403).json({ error: "not_owner" });

  // Validar campos obligatorios
  if (!name || !type || !plugin) {
    return res.status(400).json({ error: "missing_fields" });
  }

  // Validar tipo
  if (!["endpoint", "socket"].includes(type)) {
    return res.status(400).json({ error: "invalid_type" });
  }

  // Validar modo
  if (!["pull", "push"].includes(mode)) {
    return res.status(400).json({ error: "invalid_mode" });
  }

  // Validar URL solo para modo pull
  if (mode === 'pull') {
    if (!sourceUrl) return res.status(400).json({ error: "missing_source_url_for_pull" });
    
    try {
      const u = new URL(sourceUrl);
      if (!["http:", "https:", "ws:", "wss:"].includes(u.protocol)) {
        return res.status(400).json({ error: "invalid_protocol" });
      }
    } catch (e) {
      return res.status(400).json({ error: "invalid_url" });
    }
  }

  // Actualizar en la base de datos
  try {
    const updated = await LogtabModel.updateById(id, { name, type, plugin, sourceUrl, mode, pushEndpoint });
    res.json({ logtab: updated });
  } catch (error) {
    res.status(500).json({ error: "update_failed" });
  }
});

// delete
router.delete("/:id", verifyTokenMiddleware, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const found = await LogtabModel.findById(id);
    if (!found) return res.status(404).json({ error: "not_found" });
    if (found.userId !== req.user.id) return res.status(403).json({ error: "not_owner" });
    await LogtabModel.deleteById(id);
    res.json({ ok: true });
  } catch (error) {
    console.error("Error deleting logtab:", error);
    res.status(500).json({ error: "server_error" });
  }
});

export default router;