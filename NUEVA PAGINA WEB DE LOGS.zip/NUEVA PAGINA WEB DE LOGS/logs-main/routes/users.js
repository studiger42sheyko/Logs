import express from "express";
import bcrypt from "bcryptjs";
import { signToken } from "../config/auth.js";
import { UserModel } from "../models/userModel.js";

const router = express.Router();

router.post("/register", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    console.warn("⚠️ [REGISTER] Campos faltantes");
    return res.status(400).json({ error: "missing_fields" });
  }

  try {
    const existing = await UserModel.findByUsername(username);
    if (existing) {
      return res.status(400).json({ error: "user_exists" });
    }

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);
    const user = await UserModel.create({ username, passwordHash });
    const token = signToken({ id: user.id, username: user.username });

    res.json({ user: { id: user.id, username: user.username }, token });
  } catch (err) {
    res.status(500).json({ error: "server_error" });
  }
});

router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: "missing_fields" });
  }

  try {
    const user = await UserModel.findByUsername(username);
    if (!user) {
      return res.status(401).json({ error: "invalid_credentials" });
    }

    const ok = bcrypt.compareSync(password, user.password);
    if (!ok) {
      return res.status(401).json({ error: "invalid_credentials" });
    }

    const token = signToken({ id: user.id, username: user.username });

    res.json({ user: { id: user.id, username: user.username }, token });
  } catch (err) {
    res.status(500).json({ error: "server_error" });
  }
});

export default router;
