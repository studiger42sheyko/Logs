import express from "express";
import cors from "cors";
import http from "http";
import { Server } from "socket.io";
import dotenv from "dotenv";
dotenv.config();

import usersRoutes from "./routes/users.js";
import logtabsRoutes from "./routes/logtabs.js";
import logsRoutes from "./routes/logs.js";
import pluginRoutes from "./routes/plugin.js";

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.CLIENT_ORIGIN || "*",
    methods: ["GET", "POST", "DELETE"]
  }
});

app.use(express.json());
app.use(express.static("public"));
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "*" }));

app.use("/api/users", usersRoutes);
app.use("/api/logtabs", logtabsRoutes);
app.use("/api/logs", logsRoutes);
app.use("/api/plugins", pluginRoutes);

// Socket.io...
io.on("connection", (socket) => {
  console.log("Frontend socket connected:", socket.id);
  socket.on("subscribe_logtab", (logtabId) => socket.join(`logtab_${logtabId}`));
  socket.on("unsubscribe_logtab", (logtabId) => socket.leave(`logtab_${logtabId}`));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log("Server listening on port", PORT));

export { io };
