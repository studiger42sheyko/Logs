import { connectDB } from "../config/db.js";

export const PushLogModel = {
  async create({ logtabId, data, timestamp = new Date().toISOString() }) {
    const db = await connectDB();
    const result = await db.run(
      "INSERT INTO push_logs (logtabId, data, timestamp) VALUES (?, ?, ?)",
      [logtabId, data, timestamp]
    );
    return { id: result.lastID, logtabId, data, timestamp };
  },

  async findByLogtabId(logtabId, limit = 1000) {
    const db = await connectDB();
    return db.all(
      "SELECT id, logtabId, data, timestamp FROM push_logs WHERE logtabId = ? ORDER BY timestamp DESC LIMIT ?",
      [logtabId, limit]
    );
  },

  async deleteByLogtabId(logtabId) {
    const db = await connectDB();
    return db.run("DELETE FROM push_logs WHERE logtabId = ?", [logtabId]);
  },

  async cleanupOldLogs(retentionDays = 7) {
    const db = await connectDB();
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - retentionDays);
    
    return db.run(
      "DELETE FROM push_logs WHERE timestamp < ?",
      [cutoffDate.toISOString()]
    );
  }
};