import { connectDB } from "../config/db.js";

export const LogtabModel = {
  async create({ userId, name, type, plugin, sourceUrl, mode = 'pull', pushEndpoint = null }) {
    const db = await connectDB();
    const result = await db.run(
      "INSERT INTO logtabs (userId, name, type, plugin, sourceUrl, mode, pushEndpoint) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [userId, name, type, plugin, sourceUrl, mode, pushEndpoint]
    );
    return { id: result.lastID, userId, name, type, plugin, sourceUrl, mode, pushEndpoint };
  },

  async listByUser(userId) {
    const db = await connectDB();
    return db.all(
      "SELECT id, userId, name, type, plugin, sourceUrl, mode, pushEndpoint FROM logtabs WHERE userId = ?",
      [userId]
    );
  },

  async findById(id) {
    const db = await connectDB();
    return db.get(
      "SELECT id, userId, name, type, plugin, sourceUrl, mode, pushEndpoint FROM logtabs WHERE id = ?",
      [id]
    );
  },

  async updateById(id, { name, type, plugin, sourceUrl, mode, pushEndpoint }) {
    const db = await connectDB();
    await db.run(
      "UPDATE logtabs SET name = ?, type = ?, plugin = ?, sourceUrl = ?, mode = ?, pushEndpoint = ? WHERE id = ?",
      [name, type, plugin, sourceUrl, mode, pushEndpoint, id]
    );
    return { id, name, type, plugin, sourceUrl, mode, pushEndpoint };
  },

  async deleteById(id) {
    const db = await connectDB();
    return db.run("DELETE FROM logtabs WHERE id = ?", [id]);
  },
};