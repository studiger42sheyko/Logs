import { connectDB } from "../config/db.js";

export const UserModel = {
  async create({ username, passwordHash }) {
    const db = await connectDB();
    const result = await db.run(
      "INSERT INTO users (username, password) VALUES (?, ?)",
      [username, passwordHash]
    );
    return { id: result.lastID, username };
  },

  async findByUsername(username) {
    const db = await connectDB();
    return db.get("SELECT id, username, password FROM users WHERE username = ?", [username]);
  },

  async findById(id) {
    const db = await connectDB();
    return db.get("SELECT id, username FROM users WHERE id = ?", [id]);
  },
};
