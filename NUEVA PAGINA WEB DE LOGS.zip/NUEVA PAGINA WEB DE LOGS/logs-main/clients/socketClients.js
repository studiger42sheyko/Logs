import { io as ioClient } from "socket.io-client";

class SocketClientManager {
  constructor() {
    this.clients = new Map(); // key = sourceUrl, value = { socket, listenersCount }
  }

  // abrir o devolver conexión existente
  getOrCreate(sourceUrl, opts = {}) {
    if (this.clients.has(sourceUrl)) {
      const rec = this.clients.get(sourceUrl);
      rec.listenersCount++;
      return rec;
    }
    const socket = ioClient(sourceUrl, { transports: ["websocket"], timeout: 5000 });
    const rec = { socket, listenersCount: 1, messages: [] };

    socket.on("connect", () => {
      // nada por ahora
    });

    // recolecta en array mensajes entrantes en evento 'log' (convención)
    socket.on("log", (data) => {
      rec.messages.push(typeof data === "string" ? data : JSON.stringify(data));
    });

    // fallback para mensajes crudos
    socket.on("message", (data) => {
      rec.messages.push(typeof data === "string" ? data : JSON.stringify(data));
    });

    socket.on("disconnect", () => {
      // cleanup será hecho cuando listenersCount llegue a 0
    });

    this.clients.set(sourceUrl, rec);
    return rec;
  }

  release(sourceUrl) {
    const rec = this.clients.get(sourceUrl);
    if (!rec) return;
    rec.listenersCount = Math.max(0, rec.listenersCount - 1);
    if (rec.listenersCount === 0) {
      try { rec.socket.disconnect(); } catch (e) {}
      this.clients.delete(sourceUrl);
    }
  }

  // conectar temporal y esperar n ms para recolección
  async collectFor(sourceUrl, ms = 2000) {
    const rec = this.getOrCreate(sourceUrl);
    // vaciar mensajes existentes
    rec.messages = [];
    await new Promise(r => setTimeout(r, ms));
    const collected = rec.messages.slice();
    this.release(sourceUrl);
    return collected;
  }
}

export default new SocketClientManager();
