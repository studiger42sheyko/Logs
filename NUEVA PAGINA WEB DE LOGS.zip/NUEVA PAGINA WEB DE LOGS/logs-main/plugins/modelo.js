// modelo.js
export default {
  id: "modelo",
  name: "Plantilla de plugin",
  description: "Ejemplo/plantilla que explica la interface mínima",
  fields: ["col1", "col2"],
  parseLine(line) {
    const parts = line.trim().split(/\s+/);
    return { col1: parts[0] || "", col2: parts.slice(1).join(" ") || "" };
  },
  parseBatch(text) {
    return text.split(/\r?\n/).filter(Boolean).map(l => this.parseLine(l));
  },
  getTable(text) {
    const rowsObj = this.parseBatch(text);
    const columns = this.fields;
    const rows = rowsObj.map(o => columns.map(c => o[c] ?? ""));
    
    // Nueva lógica: generar HTML con objeto table
    const html = `
      <div class="log-table-container">
        <table class="log-table">
          <thead>
            <tr>
              ${columns.map(col => `<th>${col}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${rows.map(row => `
              <tr>
                ${row.map(cell => `<td>${cell}</td>`).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
    
    return {
      html,
      table: { columns, rows },
      metadata: {
        rowCount: rows.length,
        columnCount: columns.length,
        plugin: this.id
      }
    };
  }
};