// basic.js
export default {
  id: "basic",
  name: "Basic whitespace parser",
  description: "Divide cada línea por espacios y convierte en columnas",
  fields: ["c1", "c2", "c3", "rest"],
  example: "a b c rest of line",
  parseLine(line) {
    const parts = line.split(/\s+/);
    return {
      c1: parts[0] || "",
      c2: parts[1] || "",
      c3: parts[2] || "",
      rest: parts.slice(3).join(" ")
    };
  },
  parseBatch(text) {
    return text.split(/\r?\n/).filter(Boolean).map(l => this.parseLine(l));
  },
  getTable(text) {
    const objs = this.parseBatch(text);
    const columns = this.fields;
    const rows = objs.map(o => columns.map(c => o[c] ?? ""));
    
    // Nueva lógica: generar HTML con objeto table
    const html = `
      <div class="log-table-container">
        <table class="log-table">
          <thead>
            <tr>
              ${columns.map(col => `<th>${col}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${rows.map(row => `
              <tr>
                ${row.map(cell => `<td>${cell}</td>`).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
    
    return {
      html,
      table: { columns, rows },
      metadata: {
        rowCount: rows.length,
        columnCount: columns.length,
        plugin: this.id
      }
    };
  }
};